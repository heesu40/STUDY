from django.shortcuts import render , redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from IPython import embed

# Create your views here.
def signup(request):
    if request.method=="POST":
        form=UserCreationForm(request.POST) #폼에 해당부분이 채워져있을 것이다.
        # embed()
        if form.is_valid():
            user = form.save() 
            #회원가입하고 이 정보를 유지하기 위해서
            auth_login(request, user)
            return redirect("boards:index")
    else:
        form=UserCreationForm()
        # embed()

  
    context= {
        'form' :form
    }
    return render(request , 'accounts/signup.html' , context)

def login(request):

    if request.method=="POST":
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            auth_login(request, form.get_user())
            return redirect('boards:index')
        else:
            form = AuthenticationForm()
    form  = AuthenticationForm()


    context = {
        'form' : form
    }
    return render(request, 'accounts/login.html' , context)

def logout(request):
    if request.method=="POST": #POST일때만 동작 하겠끔.

        auth_logout(request)

    return redirect('boards:index')

